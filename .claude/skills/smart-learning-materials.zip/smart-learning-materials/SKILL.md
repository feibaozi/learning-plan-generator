---
name: smart-learning-materials
description: >
  针对单个知识点/概念/术语，生成结构化、多层级、多模态的高质量学习资料。
  覆盖金融与AI/科技两大领域，支持3×3深度×广度矩阵和G1-G8表达纹理自动选择，
  输出纯HTML(无CDN基线) + 可选CDN增强层和现代风格PDF。
---

# Smart Learning Materials Generator v2

## 描述

这是一个"知识深度加工引擎"。接收用户对单个知识点/概念/术语的提问，
自动判定主题领域、分析4D画像(抽象度/系统性/数学密度/演化速度)、
选择最佳表达纹理(G1-G8)、按相关度评分动态编排模块、
生成包含图表/公式/数据/案例/文献的完整学习资料。
最终输出为自包含的现代HTML网页和/或精心排版的PDF。

### v2 核心改进

| 维度 | v1.0 | v2.0 |
|---|---|---|
| 知识深度 | 固定3级(入门/进阶/专家) | 3×3矩阵: 概览/理解/精通 × 核心/标准/全景 |
| 主题分类 | 用户选 finance/ai-tech | 自动匹配60主题库 or R1-R5启发式推理 |
| 模块选择 | 硬编码include/exclude列表 | relevance_score评分(≥0.80必选, ≥0.40可选) |
| 表达风格 | 统一输出格式 | G1-G8八种纹理自动匹配 |
| 时长估算 | 固定标签(入门XX分钟) | 动态: word_count/400 + charts×1.5 + formulas×1.0 |
| Web输出 | mode-a + mode-b + CDN依赖 | 单HTML自包含 + 可选CDN增强层 |

## 配置文件索引

生成前必须加载以下配置（均位于 `resources/` 目录）：

| 文件 | 用途 | 调用阶段 |
|---|---|---|
| `topic_profiles.json` | 60主题4D画像库 + 匹配规则 | Phase 1 |
| `heuristic_rules.json` | R1-R8启发式推理(匹配失败时) | Phase 1 fallback |
| `texture_templates.json` | G1-G8纹理模板 + 逐模块Override | Phase 2, 3 |
| `module_weights.json` | relevance_base + tag_affinity + 深度×广度上限 | Phase 2 |
| `module-mapping.json` | 模块定义 + 排序 + 输出模式(v2_extensions) | Phase 2, 4 |

## 触发条件

- 用户询问某个金融概念/方法（如"什么是期权定价"、"解释一下蒙特卡洛模拟"）
- 用户询问某个AI/科技概念/技术（如"Transformer原理是什么"、"解释RLHF"）
- 用户说"帮我整理XX的学习资料"、"帮我做一个关于XX的知识页面"、"生成XX的学习材料"
- 用户提及"学习资料"、"知识卡片"、"知识图谱"并要求生成

## 指令

### Phase 1: 输入解析与主题自动分类

#### Step 1.1: 提取知识点名称

从用户输入中识别核心概念/术语。如果用户表述模糊，主动追问确认：
- "您指的是Black-Scholes期权定价模型，还是二叉树期权定价法？"
- "您想了解的是Transformer架构本身，还是基于Transformer的大语言模型？"

#### Step 1.2: 匹配 topic_profiles.json

按以下优先级尝试匹配：

1. **精确匹配**: topic name 或 aliases 与用户输入完全相同
2. **子串匹配**: 用户输入包含 topic name 或 alias
3. **关键词命中**: 用户输入中的关键词命中 `tag_index` → 推荐该 tag 下最相关的 topic
4. **Jaccard相似度**: 用户输入与 aliases 的交集/并集 > 0.3 → 取最高分

若匹配成功 → 直接获得该 topic 的完整信息：
```json
{
  "topic_id": "option-pricing",
  "topic_name": "期权定价",
  "domain": "finance",
  "tags": ["derivatives", "pricing", "quant-models"],
  "profile": {"abstract": 0.80, "systemic": 0.55, "math_density": 0.90, "temporal": 0.25},
  "suggested_texture": "G1",
  "texture_reason": "高数学密度+高抽象度→需要公式驱动的推导式表达"
}
```

#### Step 1.3: Fallback — 启发式推理 (heuristic_rules.json)

若所有匹配均失败，按 R1→R5 顺序推理：

- **R1 领域判定**: 关键词加权投票 → `finance` | `ai-tech` | `unknown`(询问用户)
- **R2 数学密度**: baseline + 关键词boost/reduce → clamp 到 [0.05, 0.98]
- **R3 抽象度**: baseline + 关键词boost/reduce → clamp 到 [0.05, 0.95]
- **R4 系统性**: baseline + 关键词boost/reduce → clamp 到 [0.10, 0.98]
- **R5 演化速度**: baseline + 关键词boost/reduce → clamp 到 [0.05, 0.95]
- **R6 纹理选择**: 计算8个 texture_score → 取最高分

#### Step 1.4: 确认深度×广度 (默认值)

v2 不再要求用户选择"入门/进阶/专家"。改为两个维度：

**深度 (ContentDepth)**:
- `概览` (multiplier=0.5) — 精简表达，每模块200-400字
- `理解` (multiplier=1.0) — **默认值**，标准深度500-800字
- `精通` (multiplier=1.6) — 深度展开800-1500字

**广度 (CoverageBreadth)**:
- `核心` (max_modules=8) — 仅必选模块(≥0.80)
- `标准` (max_modules=16) — **默认值**，核心+高相关可选
- `全景` (max_modules=24) — 核心+全部可选

用户未明确选择时，默认: **理解 × 标准**。

如果用户表达了深度/广度偏好（如"简单了解一下"→概览，"全面深入了解"→精通+全景），据此调整。

#### Step 1.5: 确认输出模式

用户可选择: `web`(默认) / `pdf` / `both`

v2 不再有 mode-a/mode-b 之分，web 输出统一为自包含 HTML。
如用户需要交互图表+公式渲染，使用 CDN 增强层（见 Phase 4）。

#### Step 1.6: 向用户确认

在开始生成前，用1-2句话确认解析结果：

```
已识别主题：【期权定价】 → 领域:金融 | 标签:衍生品/定价/量化模型
4D画像: 抽象度0.80 | 系统性0.55 | 数学密度0.90 | 演化速度0.25
表达纹理: G1(公式推导驱动型) | 深度:理解 | 广度:标准(≤16模块)
开始生成...
```

### Phase 2: 模块评分与编排

#### Step 2.1: 计算每个模块的 relevance_score

加载 `module_weights.json`，对每个模块：

```
relevance_score = CLAMP(
    relevance_base[module_id] 
    + Σ(tag_affinity[tag][module_id] for tag in topic.tags),
    0, 1
)
```

**跨领域过滤**: 非本领域的专属模块直接 `relevance_score = 0`
- finance 专属: quant_model, regulation, micro_structure, cross_market, crisis_review, institution_diff
- ai-tech 专属: architecture, compute_cost, open_source, benchmark, ethics, research_map
- 通用模块不受影响

#### Step 2.2: 模块分类与选择

```
MANDATORY (relevance_score >= 0.80):
  无条件包含，不占用 max_modules 配额外的限制
  
OPTIONAL (0.40 <= relevance_score < 0.80):
  按 relevance_score 降序排列
  取前 (max_modules - mandatory_count) 个
  
EXCLUDED (relevance_score < 0.40):
  不包含在当前主题的资料中
```

**实际 max_modules**: 取 `module_weights.json` 中 `depth_breadth_module_cap[深度_广度].max_modules`

#### Step 2.3: 加载纹理模板

根据 Phase 1 确定的 `suggested_texture`，从 `texture_templates.json` 加载对应纹理的:
- `global_params` — 全局内容比例和风格参数
- `module_overrides` — 部分模块的覆盖配置

纹理选择规则: 优先使用 topic_profiles 中的 `suggested_texture`；
若为 heuristic 推理得到的 topic，则使用 R6 计算的最优纹理。

#### Step 2.4: 模块排序

使用 `module-mapping.json` 中 `module_ordering` 的对应领域排序，
选中的模块按此顺序排列。
`texture module_overrides` 中存在 override 的模块，在同类别中优先排列。

#### Step 2.5: 动态时长估算

```
ESTIMATED_MINUTES = CEIL(
    total_words / 400 
    + total_charts × 1.5 
    + total_formulas × 1.0 
    + total_tables × 0.8
)
```

在 Phase 3 生成完成后使用实际数据重新计算。

### Phase 3: 逐模块内容生成规则

#### Step 3.1: 动态内容参数计算

对于每个选中的模块，按以下公式计算最低字数:

```
word_count = WORD_BASE × content_depth_multiplier × texture_word_factor

其中:
  WORD_BASE: 根据模块类型取值
    - 核心模块(concept/principle): 600
    - 应用模块(application/case_study): 500
    - 发展模块(development/landscape/risk): 450
    - 补充模块(glossary/learning_path/misconceptions): 350
    
  content_depth_multiplier: depth_params[深度].multiplier (0.5/1.0/1.6)
  
  texture_word_factor: 
    - 纹理中存在 module_overrides[module_id].word_count_multiplier → 使用该值
    - 否则: 1.0
```

公式和图表数量:

```
formula_count = CEIL(
    MATH_DENSITY × FORMULA_DENSITY(texture) × 3 × content_depth_multiplier
    × module_overrides中的formula_count_multiplier(默认1.0)
)

chart_count = CEIL(
    CHART_PRIORITY(texture) × 2 × content_depth_multiplier
    × module_overrides中的chart_count_multiplier(默认1.0)
)
```

#### Step 3.2: 每个模块的 JSON 输出结构

```json
{
  "module_id": "principle",
  "module_title": "核心原理",
  "module_tag": "核心概念",
  "content_type": "mixed",
  "texture_note": "G1纹理: 完整推导链，从基本假设到最终结论",
  "hook": "一句话抓住读者注意力，引发好奇或共鸣",
  "content": "Markdown格式的正文内容...",
  "formulas": [
    {
      "latex": "$$E = mc^2$$",
      "caption": "质能方程",
      "expandable": true,
      "derivation": "推导过程..."
    }
  ],
  "charts": [
    {
      "type": "echarts",
      "chart_id": "chart_principle_01",
      "echarts_option": {},
      "caption": "图：XXX示意图",
      "data_source": "数据来源：XXX",
      "responsive": true
    }
  ],
  "tables": [
    {
      "headers": ["维度", "说明", "备注"],
      "rows": [["行1列1", "行1列2", "行1列3"]],
      "caption": "表：XXX对比表"
    }
  ],
  "references": [
    {
      "title": "论文/文献标题",
      "authors": "作者",
      "year": 2024,
      "doi": "10.xxx",
      "url": "https://...",
      "type": "paper"
    }
  ],
  "key_takeaway": "一句话总结本模块核心要点"
}
```

#### Step 3.3: 纹理感知的内容风格

根据纹理 `global_params` 调整每个模块的写作风格：

- **G1(公式推导驱动)**: 
  - hook 从核心公式/方程出发
  - 推导过程连续递进，每步标注假设
  - 40-45%正文 + 30-35%公式 + 10-15%图表 + 0-5%案例

- **G2(公式+可视化)**:
  - 每个公式配一张示意图
  - hook 从可视化现象或结构问题切入
  - 35-40%正文 + 18-22%公式 + 25-30%图表 + 8-10%案例

- **G3(模型拆解)**:
  - 先拆后合：逐组件→组件交互→整体行为
  - 对比表是核心表达手法
  - 30-35%正文 + 15-20%公式 + 20-25%图表 + 15-20%对比

- **G4(叙事驱动)**:
  - 论点→论据→反驳→综合的辩论式结构
  - hook 从争议或反常识现象切入
  - 60-65%正文 + 5-8%公式 + 12-15%图表 + 10-12%案例

- **G5(平衡型)**:
  - 每个模块至少包含2种表达元素
  - 40-45%正文 + 15-18%公式 + 18-22%图表 + 12-15%案例

- **G6(系统图解)**:
  - 以图为主以文为辅
  - hook 展示全景系统图
  - 30-35%正文 + 8-10%公式 + 35-40%图表 + 12-15%案例

- **G7(叙事案例趋势)**:
  - 时间线和趋势对比图是核心
  - 优先引用2024-2026最新数据
  - 35-40%正文 + 5-8%公式 + 25-30%图表 + 18-22%案例

- **G8(教程实操)**:
  - numbered步骤+每步预期输出+常见错误
  - 核心代码片段用 syntax-highlighted block
  - 25-30%教程步骤 + 18-20%原理 + 12-15%公式 + 15-20%图表 + 15-18%代码

#### Step 3.4: 内容质量通用要求

- 所有事实性数据须有可靠来源，无法确定的标注 `[需验证]`
- 不同模块间内容不可重叠
- 语言现代、年轻化，避免教科书式僵硬表述
- 中文撰写，专业术语首次出现时附带英文原文
- 适当使用短句和留白，避免信息墙

**公式规范**:
- 使用 LaTeX 语法，`$$...$$` 或 `$...$` 包裹
- content_depth >= 1.0 时，公式必须提供可展开的推导过程
- 所有符号首次出现时必须定义

**图表规范**:
- 使用 ECharts 完整 option JSON 配置
- 图表配色使用 CSS 变量引用（确保深浅主题一致切换）
- 浅色主题色板: `['#6366f1','#8b5cf6','#a78bfa','#22d3ee','#f59e0b','#10b981','#ef4444']`
- 深色主题色板: `['#818cf8','#a78bfa','#c4b5fd','#67e8f9','#fbbf24','#34d399','#f87171']`
- 金融图表偏好: 折线图/柱状图/散点图/雷达图/热力图
- AI图表偏好: 流程图/桑基图/树图/关系图/旭日图

**引用规范**:
- 优先引用近3年顶会/顶刊论文
- 金融: Journal of Finance, Review of Financial Studies, NBER
- AI: NeurIPS, ICML, ICLR, ACL, CVPR, arXiv
- 数据来源必须标注

### Phase 4: 渲染输出

#### 4A — HTML 网页输出 (默认)

**基线模式 (无CDN)**:

1. 生成纯 HTML + 内联 CSS + 轻量 JS 的自包含文件
2. 不依赖任何外部 CDN 资源
3. 图表用纯 CSS/SVG 实现（静态展示版）
4. 公式用 Unicode 或简单 HTML 标记表示

**HTML 基结构**:
```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>[知识点名称] - 学习资料</title>
  <style>/* 内联 CSS 变量 + 主题 + 布局 + 动画 */</style>
</head>
<body>
  <!-- 进度条 -->
  <!-- 主题切换按钮 -->
  <!-- 元信息Hero卡片 -->
  <!-- 侧边栏导航 -->
  <!-- 模块内容区 (每个模块一个 <section>) -->
  <!-- 页脚导出按钮 -->
  <script>/* 轻量交互 JS: 主题切换/导航高亮/滚动动画/搜索 */</script>
</body>
</html>
```

**CDN 增强层 (可选)**:

如果用户需要交互图表和精美公式渲染，在基线 HTML 基础上注入 CDN 标签：

```html
<!-- 在 <head> 中添加 -->
<script src="https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css">
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/contrib/auto-render.min.js"></script>
```

注入 CDN 后：
- ECharts 图表获得完整交互能力（hover提示/缩放/图例切换）
- KaTeX 渲染所有 LaTeX 公式为美观的数学符号
- 页面顶部自动添加 [互动增强版] 标签

#### 4B — 通用高级 UX 标准

以下标准所有 HTML 输出必须达标：

**主题系统**:
- CSS 自定义属性 (`:root` / `[data-theme="dark"]`) 实现双主题
- localStorage 持久化主题偏好 (key: `slm-theme`)
- 切换按钮含太阳/月亮图标动画

**导航与进度**:
- 顶部固定导航栏，`backdrop-filter: blur(20px)` 毛玻璃效果
- 滚动进度条：navbar 下方 2-3px 渐变色条
- 每个模块标题旁显示 "⏱ 约 X 分钟" 阅读时间
- 桌面端右侧固定圆点导航，hover 显示模块名

**元信息卡片** (页面顶部):
```
┌──────────────────────────────────────────────────────────────┐
│  📖 [知识点名称]   🏷️ [领域]   🎯 [深度×广度]   🎨 [纹理]      │
│  ⏱️ 约X分钟阅读   📦 Y个模块   📊 Z张图表   📐 W条公式          │
└──────────────────────────────────────────────────────────────┘
```

**键盘快捷键**:
- `Ctrl+K` / `Cmd+K`: 打开搜索
- `Escape`: 关闭弹窗/搜索
- `Ctrl+D` / `Cmd+D`: 切换深色/浅色主题

**搜索系统**:
- `Ctrl+K` 触发搜索弹窗，半透明背景遮罩
- 实时过滤 (最小2字符触发)，匹配词 `<mark>` 高亮
- 搜索结果可点击跳转

**滚动与动画**:
- 模块渐显: IntersectionObserver + `translateY(24px)→0` + `opacity 0→1`
- 卡片 hover: `translateY(-2px)` + `box-shadow` 增强

**响应式设计**:
- 3断点: 桌面(>1024px) / 平板(768-1024px) / 手机(<768px)
- 手机端侧边栏隐藏，底部导航替代
- 图表容器 ResizeObserver 自适应

**导出功能**:
- "导出笔记": 收集内容生成 Markdown 复制到剪贴板
- "打印": `window.print()`，print CSS 隐藏导航等非内容元素

#### 4C — PDF 输出

1. 收集所有模块内容
2. 按序填充进 `templates/pdf/template.tex`
3. 公式使用 LaTeX 原生渲染
4. 编译: `xelatex -interaction=nonstopmode output.tex`
5. PDF 元信息: 标题=知识点名称, 关键词=领域+纹理

### Phase 5: 交付确认

生成完成后，向用户报告：

```
✅ 学习资料生成完成！

📖 知识点: [名称]
🏷️ 领域: [金融/AI科技]  |  标签: [tag1, tag2, ...]
🎯 深度: [概览/理解/精通] × 广度: [核心/标准/全景]
🎨 表达纹理: [G1-G8] — [纹理描述]

📊 内容统计:
   · 共 X 个内容模块
   · Y 张图表
   · Z 条数学公式
   · W 篇参考文献
   · 约 N 字正文

⏱️ 估算阅读时间: 约 XX 分钟

📄 产出文件:
   · HTML网页: [路径]
   · PDF文档: [路径] (如选择了pdf)

💡 试试这些操作:
   · 按 Ctrl+D 切换深色/浅色模式
   · 按 Ctrl+K 搜索任意模块
   · 点击公式展开推导过程
```

## 重要约束

1. **不要编造数据**: 所有事实性数据须有可靠来源。无法确定的标 `[需验证]`
2. **不要跳过模块**: 必须为 relevance_score ≥ 0.40 且在 max_modules 范围内的所有模块生成内容
3. **不要输出纯文本**: 图表、公式、表格是强制要求，不可省略
4. **不要生成重复内容**: 不同模块之间的内容不可重叠
5. **不要生成未验证的代码**: ECharts option 必须是语法正确的 JSON
6. **基线HTML不要依赖CDN**: 确保文件离线可打开
7. **尊重纹理风格**: Phase 2 确定的纹理必须在每个模块的内容风格中体现
8. **动态时长必须基于实际数据**: 不要使用固定标签

## 示例

### 输入示例
```
我想了解"Black-Scholes期权定价模型"，请生成学习资料
```

### 预期处理流程
1. **Phase 1**: 
   - 匹配 topic_profiles.json → topic: "Black-Scholes模型"
   - domain: finance, tags: [derivatives, pricing, quant-models, classic-models]
   - profile: {abstract:0.85, systemic:0.50, math_density:0.95, temporal:0.15}
   - suggested_texture: G1 (公式推导驱动型)
   - 默认: 理解×标准 (content_depth=1.0, max_modules=16)

2. **Phase 2**: 
   - 计算28个模块的 relevance_score
   - quant_model: 0.72(base) + 0.20(derivatives) + 0.22(pricing) + 0.20(quant-models) = 动态>0.80 → MANDATORY
   - micro_structure: 0.52(base) + 0.08(derivatives) = 0.60 → OPTIONAL
   - crisis_review: 0.60(base) + 0(no crisis tag) = 0.60 → OPTIONAL
   - 按 scores 排序取前16个
   - 加载 G1 纹理模板

3. **Phase 3**: 
   - 每模块 word_count = base × 1.0 × texture_word_factor
   - 核心模块 principle: 600 × 1.0 × 1.0 = 600字 (G1 纹理下公式占比35%)
   - 按 G1 风格生成: 公式驱动的连续推导

4. **Phase 4**: 
   - 生成纯 HTML (无CDN基线) + ECharts SVG 静态图
   - 如用户需要交互版，注入 CDN 增强层

5. **Phase 5**: 交付报告